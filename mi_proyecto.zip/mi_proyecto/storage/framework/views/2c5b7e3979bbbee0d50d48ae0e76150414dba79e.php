<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Lista de Variantes Covid 19</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
    <h1>Lista de variantes Covid19</h1>
    <p>ªActualizado el dia 28 de enero</p>
</body>
</html><?php /**PATH /Users/ulsa/Documents/mi_proyecto/resources/views/variantes/index.blade.php ENDPATH**/ ?>